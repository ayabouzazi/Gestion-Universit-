/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionuniversité;

/**
 *
 * @author pc-hamma
 */
public class Test {
    
    public static void main(String[] args){
        Esprit esprit=new Esprit();
        Etudiant e1=new Etudiant(5,"med","ben ali");
        Etudiant e2=new Etudiant(2,"med","ben salah");
        Etudiant e3=new Etudiant(3,"med","ben med");
        
        
        
        esprit.ajouterEtudiant(e1);
        esprit.ajouterEtudiant(e2);
        esprit.ajouterEtudiant(e3);
        
        
        
        esprit.displayEtudiants1();
        System.out.println("*************");
        esprit.displayEtudiants2();
        System.out.println("*******************");
        esprit.displayEtudiants3();
        esprit.trierEtudiantsParId();
        esprit.displayEtudiants3();

        

        

        

        
        
        
        
    }
    
}
