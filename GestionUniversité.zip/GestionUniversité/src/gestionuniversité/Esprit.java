/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionuniversité;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author pc-hamma
 */
public class Esprit implements University {
            List<Etudiant> list= new ArrayList(); //list<etudiant> cad on a spécifié le type de la liste


    @Override
    public void ajouterEtudiant(Etudiant e) {
      list.add(e);
    }

    @Override
    public boolean rechercherEtudiant(Etudiant e) {
        return list.contains(e);  //elle retourne true automatiquement si lelement existe sans faire if(...) return true
               
    }

    @Override
    public boolean rechercherEtudiant(String nom) {
        for(int i=0;i<list.size();i++){
            if(list.get(i).getNom().equals(nom))//get(i) retourne lelement de lindice i
                return true;
        }
        return false;
    }

    @Override
    public void supprimerEtudiant(Etudiant e) {
        list.remove(e);
    }

    public void displayEtudiants1() { //afficher les elements de la liste
        for (int i=0;i<list.size();i++)
            System.out.println(list.get(i));
            
    }
    public void displayEtudiants2() { //afficher les elements de la liste
        for (Etudiant e : list) {
            System .out.println(e);
            
        }
    }
     
    public void displayEtudiants3() { //afficher les elements de la liste
        System.out.println(list);
    }

    @Override
    public void trierEtudiantsParId() {
        Collections.sort(list);
    }

    @Override
    public void trierEtudiantsParNom() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void displayEtudiants() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
